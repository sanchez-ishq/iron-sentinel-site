# Change Management Policy
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Engineering Lead]**
*Iron Sentinel template — maps to TSC CC8*

## 1. Purpose
Ensure changes to production systems and code are reviewed, tested, approved, and
reversible — preventing unauthorized or unstable changes.

## 2. Scope
All changes to production code, infrastructure, configurations, and access controls.

## 3. Policy

### 3.1 Standard Changes *(CC8.1, CC8.2)*
- All production changes are made via version control (e.g., Git) and a pull/merge request.
- Each change requires **review and approval by at least one person other than the author**.
- Changes are **tested** (automated tests and/or manual QA) before deployment to production.

### 3.2 Environment Separation *(CC8.3)*
- Development, test/staging, and production environments are logically separated.
- Production data is not used in lower environments unless masked/anonymized.

### 3.3 Deployment *(CC8.5)*
- Deployments are performed through a controlled pipeline (CI/CD) where feasible.
- Every change must be **rollback-capable**; the rollback method is known before deploy.

### 3.4 Emergency Changes *(CC8.4)*
- Emergency changes may bypass standard timing but must be documented and retroactively
  reviewed within **[1 business day]**.

### 3.5 Infrastructure Changes
- Infrastructure changes follow the same review/approval flow; infrastructure-as-code is preferred.

## 4. Change Record (lightweight log)
| Change ID | Date | Description | Author | Reviewer/Approver | Tested? | Rollback plan |
|---|---|---|---|---|---|---|
| | | | | | | |

## 5. Evidence to Retain
PR approvals · CI/CD test results · environment list · sample change records.

## 6. Review
Reviewed at least annually. Owner: [Engineering Lead].

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
