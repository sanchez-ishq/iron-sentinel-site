# Incident Response Plan
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Security Lead]**
*Iron Sentinel template — maps to TSC CC7 (System Operations)*

## 1. Purpose
Define how [COMPANY NAME] detects, responds to, contains, and recovers from security
incidents, and how customers and authorities are notified.

## 2. Scope
Any confirmed or suspected event that threatens the confidentiality, integrity, or
availability of company or customer data or systems.

## 3. Incident Response Team
| Role | Name | Contact |
|---|---|---|
| Incident Commander | [NAME] | [PHONE/EMAIL] |
| Technical Lead | [NAME] | |
| Communications / Legal | [NAME] | |
| Executive Sponsor | [NAME] | |

## 4. Severity Classification
| Severity | Definition | Target response |
|---|---|---|
| **SEV-1 Critical** | Active breach, data exfiltration, ransomware, major outage | Immediate, 24/7 |
| **SEV-2 High** | Contained compromise, limited data exposure | Within 4 hours |
| **SEV-3 Medium** | Policy violation, malware on single endpoint, no data loss | Within 1 business day |
| **SEV-4 Low** | Suspicious activity, near-miss | Within 3 business days |

## 5. Response Lifecycle *(NIST SP 800-61 aligned)*
1. **Detect & Report** — Anyone who suspects an incident reports it to [security@COMPANY / channel] immediately. The Incident Commander logs it.
2. **Triage & Classify** — Assign severity, assemble the team, open an incident record.
3. **Contain** — Isolate affected systems/accounts; preserve evidence (do not wipe).
4. **Eradicate** — Remove the threat (malware, unauthorized access, vulnerability).
5. **Recover** — Restore systems from clean backups; verify integrity; monitor for recurrence.
6. **Notify** — Per Section 6.
7. **Post-Incident Review** — Within [5 business days], document root cause, timeline, and corrective actions.

## 6. Notification Requirements *(CC7.4, CC7.5)*
- **Customers:** Notify affected customers within the timeframe required by contract/law (commonly **72 hours** of confirmation; check each MSA/DPA).
- **Regulators:** Where applicable (e.g., state breach laws, GDPR), notify within the required window.
- **Authorities/Insurance:** Notify cyber-insurance carrier and law enforcement for SEV-1.

## 7. Incident Log (record every incident)
| ID | Date | Severity | Description | Root cause | Actions | Status | Closed |
|---|---|---|---|---|---|---|---|
| | | | | | | | |

## 8. Testing
This plan is tested at least **annually** via a tabletop exercise. Retain notes as evidence.

## 9. Review
Reviewed annually and after any SEV-1/SEV-2 incident.

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
