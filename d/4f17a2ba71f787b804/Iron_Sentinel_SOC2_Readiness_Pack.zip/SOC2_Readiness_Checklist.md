# SOC 2 Readiness Checklist
**Iron Sentinel · Aligned to the AICPA Trust Services Criteria (2017 TSC, rev. 2022)**

**How to use:** Work top to bottom. For each control, mark the **Status**:
`✅ Ready` (implemented + evidence exists) · `⚠️ Gap` (partial or no evidence) · `N/A` (out of scope, justify).
Your goal before an audit: every in-scope item is **Ready** with at least one piece of
**evidence** (a screenshot, policy, log, ticket, or config export) an auditor can sample.

> **Scope first.** SOC 2 always includes the **Common Criteria (CC / Security)**. Add
> **Availability, Confidentiality, Processing Integrity, or Privacy** only if you commit
> to them. Most SaaS startups start with **Security + Availability + Confidentiality**.

---

## CC1 — Control Environment (Governance)
| # | Control | Status | Evidence |
|---|---|---|---|
| 1.1 | Information Security Policy exists, approved by leadership, reviewed annually | | Signed policy + approval date |
| 1.2 | Org chart defines security roles & responsibilities | | Org chart / RACI |
| 1.3 | Code of conduct / acceptable use signed by all staff | | Signed acknowledgments |
| 1.4 | Background checks performed on new hires (where legal) | | HR records |
| 1.5 | Security awareness training at hire + annually | | Training completion logs |
| 1.6 | Board / leadership reviews security posture at least annually | | Meeting minutes |

## CC2 — Communication & Information
| # | Control | Status | Evidence |
|---|---|---|---|
| 2.1 | Security policies published where all staff can access them | | Intranet / shared drive link |
| 2.2 | Internal channel exists to report security concerns | | Channel + process doc |
| 2.3 | External parties can report security issues (security@ inbox / page) | | Inbox + responsible owner |
| 2.4 | System & data confidentiality commitments communicated to customers | | DPA / Terms / MSA |

## CC3 — Risk Assessment
| # | Control | Status | Evidence |
|---|---|---|---|
| 3.1 | Formal risk assessment performed at least annually | | Risk assessment doc |
| 3.2 | Risk register tracks likelihood, impact, owner, treatment | | Risk register |
| 3.3 | Fraud risk considered in the assessment | | Risk register entry |
| 3.4 | Vendor / third-party risks assessed | | Vendor risk log |
| 3.5 | Risks from significant changes (new product, infra) evaluated | | Change risk notes |

## CC4 — Monitoring
| # | Control | Status | Evidence |
|---|---|---|---|
| 4.1 | Internal control effectiveness reviewed periodically | | Review records |
| 4.2 | Vulnerability scans run on a defined cadence | | Scan reports |
| 4.3 | Penetration test performed (annually recommended) | | Pen test report |
| 4.4 | Deficiencies tracked to remediation with owners + dates | | Remediation tracker |

## CC5 — Control Activities
| # | Control | Status | Evidence |
|---|---|---|---|
| 5.1 | Control objectives mapped to specific technical/process controls | | Control matrix |
| 5.2 | Segregation of duties enforced for sensitive actions | | Role/permission matrix |
| 5.3 | Technology controls (firewalls, WAF, endpoint) deployed & documented | | Config exports |

## CC6 — Logical & Physical Access  *(the heaviest-weighted criterion)*
| # | Control | Status | Evidence |
|---|---|---|---|
| 6.1 | Access granted on least-privilege, role-based basis | | Access matrix |
| 6.2 | MFA enforced on all production, email, and admin systems | | MFA config screenshots |
| 6.3 | Unique user IDs — no shared accounts | | User list |
| 6.4 | Access reviews performed at least quarterly | | Signed access review |
| 6.5 | Offboarding revokes access within defined SLA (e.g., 24h) | | Offboarding tickets |
| 6.6 | Password policy enforced (length, rotation on compromise, manager) | | Policy + IdP config |
| 6.7 | Production data encrypted at rest and in transit (TLS 1.2+) | | Encryption config |
| 6.8 | Physical access to facilities/data centers restricted | | Badge logs / cloud provider SOC 2 |
| 6.9 | Endpoints managed (disk encryption, screen lock, AV/EDR) | | MDM / EDR dashboard |

## CC7 — System Operations (Detection & Incident Response)
| # | Control | Status | Evidence |
|---|---|---|---|
| 7.1 | Logging & monitoring enabled across production systems | | Log/SIEM config |
| 7.2 | Alerts configured for anomalous/security events | | Alert rules |
| 7.3 | Incident Response Plan documented & tested | | IR plan + tabletop notes |
| 7.4 | Incidents logged, classified, and tracked to closure | | Incident log |
| 7.5 | Customer breach-notification process defined (meets contractual/legal timelines) | | Notification procedure |

## CC8 — Change Management
| # | Control | Status | Evidence |
|---|---|---|---|
| 8.1 | Code/infra changes go through documented review & approval | | PR approvals |
| 8.2 | Changes tested before production deployment | | CI/CD + test records |
| 8.3 | Separation between dev/test/production environments | | Environment list |
| 8.4 | Emergency change process defined | | Procedure doc |
| 8.5 | Ability to roll back changes | | Rollback evidence |

## CC9 — Risk Mitigation (Vendor & Business Continuity)
| # | Control | Status | Evidence |
|---|---|---|---|
| 9.1 | Vendor inventory maintained with data-access & criticality | | Vendor register |
| 9.2 | Critical vendors' SOC 2 / security posture reviewed | | Collected SOC 2 reports |
| 9.3 | Data Processing Agreements in place with sub-processors | | Signed DPAs |
| 9.4 | Business continuity / disaster recovery plan documented | | BC/DR plan |
| 9.5 | Backups performed, encrypted, and restore-tested | | Backup + restore-test logs |

---

## Optional Trust Services Categories (only if in scope)

### Availability (A)
| # | Control | Status | Evidence |
|---|---|---|---|
| A1.1 | Capacity monitored against demand | | Monitoring dashboards |
| A1.2 | Uptime / availability commitments (SLA) defined & tracked | | SLA + uptime reports |
| A1.3 | DR plan includes RTO/RPO targets and is tested | | DR test results |

### Confidentiality (C)
| # | Control | Status | Evidence |
|---|---|---|---|
| C1.1 | Confidential data identified & classified | | Data classification matrix |
| C1.2 | Confidential data retention & disposal defined | | Retention schedule |
| C1.3 | Encryption applied to confidential data end-to-end | | Encryption config |

### Processing Integrity (PI)
| # | Control | Status | Evidence |
|---|---|---|---|
| PI1.1 | Inputs validated for completeness & accuracy | | Validation logic |
| PI1.2 | Processing errors detected, logged, and corrected | | Error handling/logs |

### Privacy (P)
| # | Control | Status | Evidence |
|---|---|---|---|
| P1.1 | Privacy notice published; consent captured | | Privacy policy |
| P1.2 | Data subject access / deletion requests handled | | DSAR process |
| P1.3 | PII inventory & data flow maps maintained | | Data flow diagram |

---

## Scoring your readiness
Count your **Ready** items across all in-scope criteria:

| Ready % | Verdict | Next move |
|---|---|---|
| 90–100% | Audit-ready | Engage an auditor for the formal examination |
| 70–89% | Close | Close the gaps; ~4–8 weeks out |
| 40–69% | Foundational gaps | Use this pack's policies to build; ~2–4 months out |
| <40% | Pre-foundation | Start with the policies in this pack; consider a vCISO sprint |

> **Stuck on the gaps?** Iron Sentinel runs a fixed-scope **SOC 2 Readiness Sprint** and
> ongoing **vCISO retainers** that take you from this checklist to auditor-ready.
> Book a free Risk Snapshot: ironsentinelhq.com

---
*© 2026 Iron Sentinel LLC. Provided for your internal use. Not legal advice. SOC 2® and the
Trust Services Criteria are products of the AICPA; Iron Sentinel is not affiliated with the AICPA.*
