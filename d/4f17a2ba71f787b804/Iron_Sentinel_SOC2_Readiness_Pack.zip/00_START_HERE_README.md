# SOC 2 Readiness Pack — Start Here
**Thank you for your purchase. — Iron Sentinel**

You now hold a complete, do-it-yourself SOC 2 readiness kit written by a consultant with
federal RMF and healthcare compliance experience. Worked in the right order, it takes you
from scattered or missing documentation to **auditor-ready**.

## Use it in this order
1. **`SOC2_Readiness_Checklist`** — Start here. Score yourself across all 5 Trust Services
   Criteria. This tells you exactly which gaps to close and how far you are from an audit.
2. **`02_Information_Security_Policy`** — Your master policy. Adopt this first; everything
   else references it.
3. **`03_Access_Control_and_MFA_Policy`** — CC6 is the most heavily audited area. Do this next.
4. **`05_Incident_Response_Plan`** — Required, and auditors test it. Fill in your team + run one tabletop.
5. **`06_Change_Management_Policy`** — For your engineering/deploy process.
6. **`07_Risk_Assessment_and_Register`** — Run one assessment; keep the register live.
7. **`04_Vendor_Risk_Management_Policy_and_Questionnaire`** — Inventory + assess your vendors.
8. **`08_Employee_Acknowledgment_and_Onboarding_Offboarding`** — Roll out to your team.

## How to customize
Replace every `[BRACKETED]` placeholder with your details (company name, dates, owners,
SLAs). Approve each policy with a real signature and date — auditors check for that.

## Important
These templates are a starting point, not legal advice, and do not by themselves make you
SOC 2 certified — a licensed CPA firm performs the actual audit. Iron Sentinel is not
affiliated with the AICPA.

## Want help closing the gaps?
If your readiness score shows real gaps, we run a fixed-scope **SOC 2 Readiness Sprint**
and ongoing **vCISO retainers** that take you from this checklist to auditor-ready.

👉 Book a free Risk Snapshot: **ironsentinelhq.com**
✉️ Questions? Reply to your receipt or email **sanchez@ironsentinelhq.com**

*© 2026 Iron Sentinel LLC.*
