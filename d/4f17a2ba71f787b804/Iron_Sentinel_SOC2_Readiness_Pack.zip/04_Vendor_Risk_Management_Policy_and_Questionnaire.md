# Vendor / Third-Party Risk Management Policy + Assessment Questionnaire
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Security Lead]**
*Iron Sentinel template — maps to TSC CC9 (Risk Mitigation)*

## PART A — POLICY

### 1. Purpose
Ensure third parties (vendors, sub-processors, contractors) that access [COMPANY NAME]
systems or data are identified, assessed, and monitored for security risk.

### 2. Scope
All third parties that store, process, transmit, or could access company or customer data.

### 3. Policy
1. **Inventory *(CC9.1)*** — A vendor register is maintained listing each vendor, the data they access, criticality, and review date.
2. **Risk tiering** — Vendors are tiered by data sensitivity and access:
   - **Critical** — access to production/customer data (e.g., cloud host, auth provider, payment processor)
   - **Important** — access to internal/business data
   - **Low** — no sensitive data access
3. **Due diligence *(CC9.2)*** — Before onboarding and at least annually for Critical vendors, collect and review their SOC 2 / ISO 27001 report or complete the questionnaire (Part B).
4. **Contracts & DPAs *(CC9.3)*** — Critical/Important vendors must have a contract and, where personal data is processed, a Data Processing Agreement.
5. **Offboarding** — On termination, access is revoked and data return/deletion is confirmed.

### 4. Evidence to Retain
Vendor register · collected SOC 2/ISO reports · completed questionnaires · signed DPAs.

---

## PART B — VENDOR SECURITY QUESTIONNAIRE
*Send to vendors that cannot provide a current SOC 2 / ISO 27001 report.*

**Vendor:** ____________  **Service:** ____________  **Data accessed:** ____________  **Tier:** ______

| # | Question | Response |
|---|---|---|
| 1 | Do you hold SOC 2 Type II, ISO 27001, or equivalent? (attach) | |
| 2 | Is customer data encrypted in transit and at rest? | |
| 3 | Is MFA enforced for employee and admin access? | |
| 4 | Do you perform background checks on staff with data access? | |
| 5 | Do you have a documented, tested incident response plan? | |
| 6 | What is your breach-notification commitment (timeframe)? | |
| 7 | Do you perform annual penetration testing / vuln scanning? | |
| 8 | Are backups performed, encrypted, and restore-tested? | |
| 9 | Do you use sub-processors? If so, list them. | |
| 10 | Will you sign a Data Processing Agreement? | |
| 11 | How is our data returned or destroyed at contract end? | |
| 12 | Do you maintain cyber liability insurance? Limits? | |

**Reviewer:** ____________  **Decision:** ☐ Approve ☐ Approve w/ conditions ☐ Reject  **Date:** ______

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
