# Access Control & MFA Policy
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Security Lead]**
*Iron Sentinel template — maps to TSC CC6 (Logical & Physical Access)*

## 1. Purpose
Define how access to [COMPANY NAME] systems and data is granted, reviewed, and revoked,
ensuring least-privilege access and strong authentication. CC6 is the most heavily sampled
criterion in a SOC 2 audit — this policy is your highest-priority control.

## 2. Scope
All systems, applications, cloud environments, and data stores — production and corporate.

## 3. Policy

### 3.1 Account Management *(CC6.1, CC6.3)*
- Every user has a **unique** account. **Shared/generic accounts are prohibited.**
- Access is granted on a **least-privilege, role-based** basis, approved by the resource owner.
- Access requests and approvals are recorded (ticket, form, or IdP log).

### 3.2 Authentication *(CC6.2, CC6.6)*
- **MFA is mandatory** on all production systems, email, cloud consoles, code repositories, and any administrative access.
- Passwords meet: minimum [12] characters, complexity per [IdP], no reuse of known-breached passwords, rotation on suspected compromise.
- SSO via [Okta / Google / Microsoft Entra] is used wherever supported.

### 3.3 Privileged Access *(CC6.1, CC5.2)*
- Administrative privileges are restricted to named individuals with a documented business need.
- Segregation of duties is enforced for sensitive actions (e.g., the person who writes code does not unilaterally approve and deploy to production where avoidable).

### 3.4 Access Reviews *(CC6.4)*
- User access is reviewed at least **quarterly** by resource owners.
- Reviews are documented and signed; excess access is revoked promptly.

### 3.5 Provisioning & Deprovisioning *(CC6.5)*
- New access is provisioned only after manager approval.
- Upon termination or role change, access is revoked within **[24 hours]**. Offboarding is tracked to completion.

### 3.6 Endpoint & Physical Access *(CC6.8, CC6.9)*
- Endpoints accessing company data require disk encryption, screen lock, and EDR/AV.
- Physical access to offices/facilities is restricted; cloud data-center physical security is inherited from the provider's SOC 2 report.

## 4. Evidence to Retain (for the auditor)
Access matrix · MFA configuration screenshots · quarterly access-review records · offboarding tickets · IdP/password policy config.

## 5. Review
Reviewed at least annually. Owner: [Security Lead].

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
