# Employee Security Acknowledgment + Onboarding / Offboarding Checklist
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [HR + Security Lead]**
*Iron Sentinel template — maps to TSC CC1 (Control Environment) & CC6 (Access)*

## PART A — EMPLOYEE SECURITY ACKNOWLEDGMENT

I, the undersigned, acknowledge that I have received, read, and agree to comply with
[COMPANY NAME]'s Information Security Policy and related policies (Acceptable Use, Access
Control, Incident Response). I understand that:

- I will protect company and customer data and use it only for authorized purposes.
- I will use strong, unique credentials and MFA where required.
- I will report any suspected security incident immediately to [security@COMPANY].
- Violation may result in disciplinary action up to termination and legal action.

**Employee name:** ____________________  **Signature:** ____________________  **Date:** __________
**Manager:** ____________________  **Signature:** ____________________  **Date:** __________

---

## PART B — ONBOARDING CHECKLIST *(complete before/at start)*
| ✓ | Step | Owner |
|---|---|---|
| ☐ | Background check completed (where legal) | HR |
| ☐ | Security Acknowledgment signed (Part A) | HR |
| ☐ | Security awareness training assigned & completed | Security |
| ☐ | Accounts provisioned least-privilege, role-based (manager approved) | IT |
| ☐ | MFA enrolled on all required systems | IT |
| ☐ | Company device issued + encrypted + EDR installed | IT |
| ☐ | Access additions recorded in access matrix | Security |

## PART C — OFFBOARDING CHECKLIST *(complete within [24h] of departure)* *(CC6.5)*
| ✓ | Step | Owner |
|---|---|---|
| ☐ | All system/app access revoked (SSO, email, repos, cloud, prod) | IT |
| ☐ | MFA tokens / sessions invalidated | IT |
| ☐ | Company devices returned / remotely wiped | IT |
| ☐ | Physical access (badges/keys) collected | Ops |
| ☐ | Email forwarded/archived per policy | IT |
| ☐ | Removal recorded in access matrix; offboarding ticket closed | Security |

## Evidence to Retain
Signed acknowledgments · training logs · onboarding/offboarding tickets.

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
