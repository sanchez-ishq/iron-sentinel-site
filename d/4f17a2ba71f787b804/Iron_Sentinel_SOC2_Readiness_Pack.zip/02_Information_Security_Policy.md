# Information Security Policy
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [CISO / Security Lead]**
*Iron Sentinel template — aligned to AICPA Trust Services Criteria (CC1–CC9)*

## 1. Purpose
This policy establishes [COMPANY NAME]'s commitment to protecting the confidentiality,
integrity, and availability of information assets and customer data. It is the master
policy under which all sub-policies (Access Control, Incident Response, Change Management,
Vendor Risk, etc.) operate.

## 2. Scope
Applies to all employees, contractors, interns, and third parties who access [COMPANY
NAME] systems, networks, or data — including all production, corporate, and cloud
environments.

## 3. Roles & Responsibilities *(CC1)*
- **Leadership / Executive Sponsor** — approves this policy, allocates resources, reviews posture at least annually.
- **Security Lead / CISO** — owns the security program, maintains policies, runs risk assessments.
- **System / Engineering Owners** — implement controls in their systems.
- **All Personnel** — comply with policies, complete training, report incidents.

## 4. Policy Statements
1. **Risk management** *(CC3)* — A formal risk assessment is performed at least annually; risks are tracked in a risk register with owners and treatment plans.
2. **Access control** *(CC6)* — Access is least-privilege and role-based; MFA is required on all production, email, and administrative systems; access is reviewed quarterly. See *Access Control & MFA Policy*.
3. **Data protection** *(CC6.7)* — Confidential and customer data is encrypted in transit (TLS 1.2+) and at rest. Data is classified and handled per its classification.
4. **Change management** *(CC8)* — Changes to production systems follow documented review, testing, and approval. See *Change Management Policy*.
5. **Incident response** *(CC7)* — Security events are logged, monitored, and handled per the *Incident Response Plan*. Customers are notified of breaches within contractual/legal timelines.
6. **Vendor management** *(CC9)* — Third parties with access to data are inventoried and assessed. See *Vendor Risk Management Policy*.
7. **Security awareness** *(CC1.5)* — All personnel complete security training at hire and annually.
8. **Business continuity** *(CC9.4)* — Backups are performed, encrypted, and restore-tested; a BC/DR plan is maintained.
9. **Acceptable use** — Personnel use systems and data only for authorized business purposes.

## 5. Compliance & Enforcement
Violations may result in disciplinary action up to and including termination and legal
action. Exceptions require documented approval from the Security Lead.

## 6. Review
Reviewed and approved at least annually, or after any significant change to the business,
systems, or threat landscape.

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |

**Approved by:** ______________________  **Title:** ____________  **Date:** __________
