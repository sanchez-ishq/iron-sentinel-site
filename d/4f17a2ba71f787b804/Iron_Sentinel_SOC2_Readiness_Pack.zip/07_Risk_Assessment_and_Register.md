# Risk Assessment Template + Risk Register
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Security Lead]**
*Iron Sentinel template — maps to TSC CC3 (Risk Assessment)*

## PART A — RISK ASSESSMENT METHODOLOGY

### 1. Purpose
Provide a repeatable method to identify, analyze, and treat risks to [COMPANY NAME]'s
information assets — performed at least **annually** and on significant change.

### 2. Process
1. **Identify** assets and the threats/vulnerabilities to them (consider: data breach, account compromise, vendor failure, insider threat, outage, fraud).
2. **Analyze** each risk: rate **Likelihood** (1–5) and **Impact** (1–5).
3. **Score** = Likelihood × Impact (1–25).
4. **Treat** — choose: Mitigate, Accept, Transfer (e.g., insurance), or Avoid.
5. **Assign** an owner and target date; **track** in the register (Part B).
6. **Review** open risks quarterly.

### 3. Risk Rating Scale
| Score | Rating | Action expectation |
|---|---|---|
| 15–25 | High | Treat now; executive visibility |
| 8–14 | Medium | Plan treatment; track to closure |
| 1–7 | Low | Accept or monitor |

---

## PART B — RISK REGISTER
*(In the delivered pack this ships as an Excel file; reproduced here for reference.)*

| ID | Risk description | Category | Likelihood (1-5) | Impact (1-5) | Score | Treatment | Owner | Target date | Status |
|---|---|---|---|---|---|---|---|---|---|
| R-01 | No MFA on a production system | Access | 4 | 5 | 20 | Mitigate — enforce MFA | | | Open |
| R-02 | Critical vendor lacks SOC 2 | Vendor | 3 | 4 | 12 | Transfer/Assess — collect report or replace | | | Open |
| R-03 | Backups not restore-tested | Continuity | 3 | 5 | 15 | Mitigate — schedule restore test | | | Open |
| R-04 | No documented incident response | Operations | 3 | 4 | 12 | Mitigate — adopt IR plan | | | Open |
| R-05 | Offboarding access lingers | Access | 3 | 4 | 12 | Mitigate — 24h revocation SLA | | | Open |
| R-... | [add your own] | | | | | | | | |

## Evidence to Retain
Completed annual risk assessment · current risk register · quarterly review notes.

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
