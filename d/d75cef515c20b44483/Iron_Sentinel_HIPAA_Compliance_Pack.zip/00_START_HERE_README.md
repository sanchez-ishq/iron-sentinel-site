# HIPAA Compliance Pack — Start Here
**Thank you for your purchase. — Iron Sentinel**

A do-it-yourself HIPAA kit written with healthcare-IT compliance experience. Worked in order,
it closes the gaps that actually get small practices penalized.

## Use it in this order
1. **`HIPAA_Security_Rule_Readiness_Checklist`** — Score yourself across Administrative,
   Physical, and Technical safeguards. This shows your exposure and what to fix first.
2. **`HIPAA_Required_Policies`** — Adopt the policy bundle. Pay special attention to:
   - **§2 Security Risk Analysis** — HIPAA *requires* a documented one. Do this first.
   - **Appendix: BAA template** — get a signed BAA from every vendor that touches PHI.
3. Fill every `[BRACKET]` with your details. Assign a **Security Official**. Sign and date.
4. Run **HIPAA training** for all workforce and log it.

## The two things to do this week
- ✅ Complete and **document** a Security Risk Analysis (checklist item A1).
- ✅ Inventory vendors that touch PHI and execute a **BAA** for each (A14).
These are the two most common — and most penalized — gaps.

## Important
Templates only — **not legal advice**, and they do not by themselves make you "HIPAA certified"
(no such government certification exists). Have counsel review the BAA before use.

## Want help closing the gaps?
Iron Sentinel runs HIPAA readiness sprints and ongoing **vCISO retainers**.
👉 Book a free Risk Snapshot: **ironsentinelhq.com** · ✉️ **sanchez@ironsentinelhq.com**

*© 2026 Iron Sentinel LLC.*
