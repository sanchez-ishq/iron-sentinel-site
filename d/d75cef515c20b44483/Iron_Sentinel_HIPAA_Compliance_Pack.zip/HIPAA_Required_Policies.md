# HIPAA Required Policies Bundle
**[PRACTICE/COMPANY NAME] · Version 1.0 · Effective [DATE] · Security Official: [NAME]**
*Iron Sentinel template — supports 45 CFR Part 164. Not legal advice; have counsel review the BAA.*

---

## 1. Security Management & Sanction Policy (§164.308(a)(1))
[NAME] protects the confidentiality, integrity, and availability of electronic protected
health information (ePHI). The **Security Official** ([NAME]) owns this program.
- A documented **Security Risk Analysis** is performed at least annually and on significant change.
- Identified risks are tracked to remediation (see Risk Register, §3).
- **Sanctions:** Workforce members who violate these policies face discipline up to termination,
  scaled to the severity of the violation. Sanctions are documented.

## 2. Security Risk Analysis — Methodology (§164.308(a)(1)(ii)(A))
1. Inventory all systems/locations that create, receive, maintain, or transmit ePHI.
2. Identify threats & vulnerabilities to that ePHI.
3. Rate **Likelihood (1–5)** × **Impact (1–5)** = risk score.
4. Determine current controls and residual risk.
5. Document treatment (mitigate/accept/transfer), owner, and date.
6. Retain the analysis for 6 years; review annually.

**Risk Register**
| ID | ePHI asset | Threat/Vuln | L | I | Score | Treatment | Owner | Date |
|---|---|---|---|---|---|---|---|---|
| H-01 | [EHR system] | No MFA | 4 | 5 | 20 | Enforce MFA | | |
| H-02 | [Email w/ PHI] | Unencrypted transmission | 4 | 4 | 16 | Enable TLS/secure msg | | |
| H-03 | [Vendor X] | No BAA on file | 3 | 5 | 15 | Execute BAA | | |

## 3. Access Control & Authentication (§164.312(a),(d))
- Each user has a **unique ID**; no shared logins.
- Access to ePHI is **role-based, minimum-necessary**.
- **MFA** is required for systems containing ePHI and remote access.
- **Automatic logoff** after [15] minutes of inactivity.
- **Emergency access** procedure: [describe break-glass process].

## 4. Workforce Security & Training (§164.308(a)(3),(5))
- Access authorized by [role] before granting; revoked within [24h] of termination.
- All workforce complete **HIPAA training** at hire and annually; logged below.
- **Workforce HIPAA Acknowledgment** signed by each member.

**Training Log**
| Name | Role | Training date | Acknowledgment signed |
|---|---|---|---|
| | | | |

## 5. Contingency Plan (§164.308(a)(7))
- **Backups** of ePHI performed [daily], encrypted, and **restore-tested** [quarterly].
- **Disaster Recovery:** restore systems to meet RTO [__] / RPO [__].
- **Emergency Mode:** maintain critical operations and ePHI access during emergencies.

## 6. Security Incident & Breach Notification (§164.308(a)(6), §164.400–414)
- All suspected incidents reported to the Security Official and logged.
- **Breach risk assessment (4 factors):** nature/extent of PHI; who accessed it; whether PHI
  was actually acquired/viewed; extent of mitigation.
- If a breach is confirmed:
  - **Individuals** notified without unreasonable delay, **≤60 days** of discovery.
  - **HHS** notified immediately if **≥500** individuals; otherwise via the annual log.
  - **Media** notified if **≥500** in one state/jurisdiction.
- Maintain a **breach log** for 6 years.

## 7. Device & Media Controls / Disposal (§164.310(d))
- Track devices/media containing ePHI.
- **Sanitize** (wipe/destroy) PHI before disposal or re-use; log disposal.

---

## APPENDIX — Business Associate Agreement (BAA) Template (§164.314(a))
> ⚠️ Have a licensed attorney review before use. [[GC — General Counsel & Compliance|GC]] owns final language.

This Business Associate Agreement ("Agreement") is between **[COVERED ENTITY]** ("Covered
Entity") and **[BUSINESS ASSOCIATE]** ("Business Associate"), effective **[DATE]**.

1. **Permitted Uses.** Business Associate may use/disclose PHI only as permitted by this
   Agreement or required by law, and only the **minimum necessary**.
2. **Safeguards.** Business Associate will implement administrative, physical, and technical
   safeguards that reasonably protect ePHI per the HIPAA Security Rule.
3. **Subcontractors.** Business Associate ensures any subcontractor that handles PHI agrees to
   the same restrictions (flow-down BAA).
4. **Reporting.** Business Associate reports any security incident or breach of unsecured PHI
   to Covered Entity **without unreasonable delay and no later than [X] days**.
5. **Access/Amendment/Accounting.** Business Associate supports Covered Entity's obligations to
   provide individuals access, amendment, and an accounting of disclosures.
6. **Return/Destruction.** On termination, Business Associate returns or destroys all PHI where
   feasible; otherwise extends protections.
7. **Termination.** Covered Entity may terminate for material breach.

**Covered Entity:** ______________  **Business Associate:** ______________  **Date:** ______

---
*© 2026 Iron Sentinel LLC. Templates only; not legal advice.*
