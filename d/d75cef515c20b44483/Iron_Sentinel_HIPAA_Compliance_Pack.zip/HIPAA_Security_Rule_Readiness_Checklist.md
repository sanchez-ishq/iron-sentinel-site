# HIPAA Security Rule Readiness Checklist
**Iron Sentinel · Mapped to 45 CFR §164.308 / .310 / .312 + Breach Notification Rule**

**How to use:** For each item mark **Status** — `✅ Met` (implemented + documented) ·
`⚠️ Gap` (missing or undocumented). HIPAA requires both the *control* and the *documentation*
of it (§164.316). Retain evidence for 6 years.

> **Note on "required" vs "addressable":** Some Security Rule items are *addressable* — you
> must implement them OR document why an alternative is reasonable. Addressable ≠ optional.

---

## A. Administrative Safeguards (§164.308)
| # | Requirement | Spec | Status | Evidence |
|---|---|---|---|---|
| A1 | **Security Risk Analysis** — accurate, thorough, documented | Required | | Risk analysis doc |
| A2 | **Risk Management** — measures to reduce risks to reasonable levels | Required | | Remediation plan |
| A3 | **Sanction Policy** for workforce violations | Required | | Sanction policy |
| A4 | **Information System Activity Review** (log review) | Required | | Review records |
| A5 | Assigned **Security Official** | Required | | Named individual |
| A6 | **Workforce authorization / supervision** procedures | Addressable | | Access procedures |
| A7 | **Workforce clearance / termination** procedures | Addressable | | On/offboarding records |
| A8 | **Security awareness & training** for all workforce | Required* | | Training log |
| A9 | **Malware protection, log-in monitoring, password mgmt** | Addressable | | Config + policy |
| A10 | **Security Incident Procedures** (identify, respond, document) | Required | | Incident log |
| A11 | **Contingency Plan** — data backup, disaster recovery, emergency mode | Required | | BC/DR + backup plan |
| A12 | **Backups** performed and **restore-tested** | Required | | Backup + restore logs |
| A13 | **Evaluation** — periodic compliance review | Required | | Evaluation record |
| A14 | **Business Associate Agreements** with all BAs handling PHI | Required | | Signed BAAs |

## B. Physical Safeguards (§164.310)
| # | Requirement | Spec | Status | Evidence |
|---|---|---|---|---|
| B1 | **Facility Access Controls** — limit physical access to systems | Addressable | | Access procedures |
| B2 | **Workstation Use** policy (appropriate use of workstations) | Required | | Workstation policy |
| B3 | **Workstation Security** (physical safeguards for workstations) | Required | | Controls list |
| B4 | **Device & Media Controls** — disposal, re-use, accountability | Required/Addr | | Disposal records |
| B5 | **Media disposal** sanitizes PHI before disposal/re-use | Required | | Disposal log |

## C. Technical Safeguards (§164.312)
| # | Requirement | Spec | Status | Evidence |
|---|---|---|---|---|
| C1 | **Access Control** — unique user IDs | Required | | User list |
| C2 | **Emergency access** procedure | Required | | Procedure |
| C3 | **Automatic logoff** | Addressable | | Config |
| C4 | **Encryption/decryption** of ePHI at rest | Addressable | | Encryption config |
| C5 | **Audit Controls** — record/examine system activity | Required | | Audit log config |
| C6 | **Integrity** — protect ePHI from improper alteration/destruction | Addressable | | Controls |
| C7 | **Person/Entity Authentication** (verify identity; MFA) | Required | | MFA config |
| C8 | **Transmission Security** — encrypt ePHI in transit (TLS) | Addressable | | TLS config |

## D. Breach Notification Rule (§164.400–414)
| # | Requirement | Status | Evidence |
|---|---|---|---|
| D1 | Documented breach **risk assessment** process (4-factor) | | Procedure |
| D2 | **Individual notice** within 60 days of discovery | | Template |
| D3 | **HHS notice** (immediately if ≥500 affected; annual log if <500) | | Procedure |
| D4 | **Media notice** if ≥500 in a state/jurisdiction | | Procedure |
| D5 | Breach **log** maintained | | Breach log |

## E. Documentation (§164.316)
| # | Requirement | Status | Evidence |
|---|---|---|---|
| E1 | Policies & procedures maintained in writing | | Policy set |
| E2 | Documentation retained **6 years** | | Retention practice |
| E3 | Documentation reviewed & updated periodically | | Review log |

---

## Scoring
| Met % | Verdict | Next move |
|---|---|---|
| 90–100% | Strong posture | Maintain; annual risk analysis |
| 70–89% | Minor gaps | Close addressable items; document decisions |
| 40–69% | Material gaps | Use this pack's policies + risk analysis now |
| <40% | High exposure | Prioritize Risk Analysis (A1) + BAAs (A14) immediately; consider a vCISO sprint |

> **The two gaps that get practices fined first:** missing **Security Risk Analysis (A1)** and
> missing **BAAs (A14)**. Close those this week.

> **Need help?** Iron Sentinel runs HIPAA readiness sprints + vCISO retainers. Free Risk
> Snapshot: ironsentinelhq.com

---
*© 2026 Iron Sentinel LLC. For internal use. Not legal advice. There is no official government
"HIPAA certification"; this checklist supports compliance readiness.*
