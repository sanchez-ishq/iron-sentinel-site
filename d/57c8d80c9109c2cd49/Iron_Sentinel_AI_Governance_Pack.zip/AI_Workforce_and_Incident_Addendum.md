# Employee AI Use Acknowledgment + Quick-Reference + AI Incident Addendum
**[COMPANY NAME] · Version 1.0 · Effective [DATE]**
*Iron Sentinel template — companion to the AI Acceptable Use & Governance Policy.*

## PART A — EMPLOYEE AI USE ACKNOWLEDGMENT
I acknowledge I have read and agree to comply with [COMPANY NAME]'s AI Acceptable Use &
Governance Policy. I understand that:
- I will only use **approved AI tools** for company work (no shadow AI).
- I will **never** enter confidential, personal, regulated (PII/PHI), or secret data into a
  public/consumer AI tool.
- I will **verify AI output** before relying on it, and a human approves consequential decisions.
- I will report AI-related incidents (mis-entered data, harmful output, suspected prompt
  injection) immediately.

**Employee:** ______________  **Signature:** ______________  **Date:** ________

---

## PART B — AI USE QUICK-REFERENCE CARD (pin this up)
✅ **DO:** use approved tools · keep data public/non-sensitive unless the tool is enterprise-approved ·
treat output as a draft · cite/verify · ask the AI Lead before adopting a new tool.
🚫 **DON'T:** paste customer PII/PHI, passwords, secrets, or NDA'd code into public chatbots ·
auto-run AI-generated code/commands · let AI make hiring/lending/clinical/legal calls unattended ·
trust output you can't verify.

---

## PART C — AI INCIDENT & MISUSE RESPONSE ADDENDUM
Extends the Incident Response Plan for AI-specific events.

**AI incident types to watch:**
- **Data leakage** — sensitive data entered into the wrong/unapproved AI tool.
- **Prompt injection (OWASP LLM01)** — untrusted content manipulates an AI tool/agent.
- **Harmful/biased output acted upon** — an AI-influenced decision caused harm.
- **Insecure output (LLM05)** — AI-generated code/command caused a security issue.
- **Agent overreach** — an AI agent took an unintended or unauthorized action.

**Response steps:**
1. **Report** to the AI Lead + follow the standard Incident Response Plan.
2. **Contain** — revoke the tool's access / stop the agent; if data leaked, treat as a potential
   data breach (assess notification duties).
3. **Assess** — what data, which tool, retention/training implications, who was affected.
4. **Remediate** — request vendor deletion, rotate exposed secrets, correct downstream decisions.
5. **Review** — update the approved-tools list, policy, and training.

**AI Incident Log**
| ID | Date | Type | Tool | Description | Data involved | Actions | Status |
|---|---|---|---|---|---|---|---|

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
