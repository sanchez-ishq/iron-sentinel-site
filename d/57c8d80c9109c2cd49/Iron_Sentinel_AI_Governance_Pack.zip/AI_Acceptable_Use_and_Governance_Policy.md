# AI Acceptable Use & Governance Policy
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [Security/AI Lead]**
*Iron Sentinel template — aligned to NIST AI Risk Management Framework (RMF) and the OWASP LLM Top 10. Not legal advice.*

## 1. Purpose
Enable [COMPANY NAME] to adopt AI tools productively while protecting confidential, personal,
and regulated data, and managing the new risks AI introduces (data leakage, inaccurate output,
prompt injection, over-reliance). This policy governs all use of AI systems at the company.

## 2. Scope
All employees, contractors, and vendors using AI tools for company work — including public
chatbots (ChatGPT, Gemini, Claude), embedded AI features (Copilot, AI scribes/notetakers),
and any AI agents or automations.

## 3. Governance & Roles *(NIST AI RMF: GOVERN)*
- **AI Lead / Security Official ([NAME])** owns this policy, the approved-tools list, and the AI risk register.
- New AI tools must be **reviewed and approved** before use on company data (see §6).
- This policy is reviewed at least annually and when significant new AI tools are adopted.

## 4. Approved Tools & Shadow AI
- Only AI tools on the **Approved AI Tools list** may be used with company data.
  | Tool | Approved use | Data allowed | Owner |
  |---|---|---|---|
  | [e.g. ChatGPT Team] | Drafting, code help | Non-sensitive only | |
  | [e.g. Copilot] | Internal docs | Internal | |
- **Shadow AI is prohibited:** do not use unapproved AI tools (including free/personal accounts)
  for company work. Request approval instead.

## 5. Data Handling Rules *(the core control)* *(OWASP LLM02: Sensitive Information Disclosure)*
- **Never input into a public/consumer AI tool:** customer PII, PHI, cardholder data,
  credentials/secrets, source code under NDA, trade secrets, or anything classified Confidential+.
- Use only **enterprise AI tools with a signed agreement** (and **no-training** / data-retention
  controls enabled) for anything beyond public information.
- Assume anything typed into a consumer chatbot **may be retained and used for training.**
- Treat AI output as **draft, not truth** — verify facts, figures, code, and citations before use
  *(OWASP LLM09: Overreliance; LLM08: hallucination harms)*.

## 6. Approving a New AI Tool *(NIST AI RMF: MAP / MEASURE)*
Before approval, the AI Lead assesses: what data it touches, vendor security posture (SOC 2 /
ISO), data-retention & training terms, whether a DPA/BAA is needed, and model risk. Record the
decision in the **AI Tool Risk Register**.

## 7. Human-in-the-Loop *(NIST AI RMF: MANAGE)*
- A **human must review and approve** AI output before it is used in any consequential decision —
  hiring, lending, clinical, legal, financial, security, or customer-facing commitments.
- AI may **assist** these decisions; it may not **make** them unattended.
- AI agents/automations that act on systems require a human gate on irreversible or
  compliance-relevant actions.

## 8. Prohibited Uses
- Entering prohibited data (see §5) into unapproved tools.
- Using AI to generate malware, harassment, discriminatory decisions, or to impersonate people.
- Presenting AI output as human-authored where disclosure is legally/ethically required.
- Bypassing security controls or exfiltrating data via AI tools.

## 9. AI-Specific Security Risks to Watch *(OWASP LLM Top 10 awareness)*
- **Prompt injection (LLM01):** be cautious pasting untrusted content into AI; it can carry hidden instructions.
- **Sensitive disclosure (LLM02):** see §5.
- **Insecure output handling (LLM05):** never auto-execute AI-generated code/commands without review.
- **Overreliance (LLM09):** verify before acting.

## 10. Incident Handling
Suspected AI-related incidents (data entered into the wrong tool, a leaked secret, harmful or
biased output acted upon, a prompt-injection event) must be reported to the AI Lead immediately
and handled under the company **Incident Response Plan**.

## 11. Training & Acknowledgment
All staff complete brief AI-use training at rollout and sign the **Employee AI Use Acknowledgment**.

## 12. Review
| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |

**Approved by:** ______________________  **Title:** ____________  **Date:** __________

---
*© 2026 Iron Sentinel LLC. Template for internal use; not legal advice. Aligned to NIST AI RMF
and the OWASP Top 10 for LLM Applications; Iron Sentinel is not affiliated with NIST or OWASP.*
