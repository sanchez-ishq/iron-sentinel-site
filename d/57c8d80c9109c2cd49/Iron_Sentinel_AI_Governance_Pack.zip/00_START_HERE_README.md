# AI Acceptable Use & Governance Pack — Start Here
**Thank you for your purchase. — Iron Sentinel**

Everything your team needs to adopt AI tools safely — the policy, the risk assessment, the
vendor checklist, and the workforce + incident pieces. Built on NIST AI RMF and the OWASP LLM
Top 10, by a consultant holding SecAI+ and deep GRC credentials.

## Use it in this order
1. **`AI_Acceptable_Use_and_Governance_Policy`** — adopt this first. Fill in your approved-tools
   list and data rules. Get leadership sign-off.
2. **`AI_Risk_and_Vendor_Assessment`** — run the risk assessment on each AI tool you use; send the
   vendor questionnaire to any AI vendor touching sensitive data.
3. **`AI_Workforce_and_Incident_Addendum`** — roll out the acknowledgment + quick-reference to
   staff; bolt the incident addendum onto your incident response plan.

## The two moves to make this week
- ✅ Publish the **approved-AI-tools list** and the data rule: *no sensitive data in public chatbots.*
- ✅ Get every employee to sign the **AI Use Acknowledgment.**

## Important
Templates only — **not legal advice**, and they don't by themselves make you "compliant." They
establish responsible AI governance and reduce risk. Keep a human in the loop on consequential
AI-assisted decisions.

## Want help?
Iron Sentinel offers a free **AI Security Snapshot** and vCISO retainers that include AI governance.
👉 ironsentinelhq.com · ✉️ sanchez@ironsentinelhq.com

*© 2026 Iron Sentinel LLC.*
