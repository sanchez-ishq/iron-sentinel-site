# AI Tool Risk Assessment + Register & Vendor/LLM Due-Diligence Questionnaire
**[COMPANY NAME] · Version 1.0 · Effective [DATE] · Owner: [AI/Security Lead]**
*Iron Sentinel template — aligned to NIST AI RMF (MAP/MEASURE) and OWASP LLM Top 10.*

## PART A — AI TOOL RISK ASSESSMENT METHODOLOGY
Before approving any AI tool (and at least annually), assess:
1. **Data exposure** — what data could enter it? (public → regulated/PHI/PII/secrets)
2. **Vendor posture** — SOC 2 / ISO 27001? data-retention & training terms? sub-processors?
3. **Model risk** — accuracy, bias, hallucination impact on decisions; OWASP LLM exposure.
4. **Integration risk** — what systems/permissions does it touch? can it take actions?

Score **Likelihood (1–5) × Impact (1–5)**; treat High (15–25) before approval.

## PART B — AI TOOL RISK REGISTER
| ID | AI tool | Use case | Data class | Vendor SOC2? | Training opt-out? | L | I | Score | Decision | Owner |
|---|---|---|---|---|---|---|---|---|---|---|
| AI-01 | [ChatGPT Team] | Drafting | Non-sensitive | ☐ | ☐ | 2 | 3 | 6 | Approved (no sensitive data) | |
| AI-02 | [AI scribe] | Clinical notes | PHI | ☐ | ☐ | 4 | 5 | 20 | Pending BAA + review | |
| AI-03 | [Copilot] | Code/docs | Internal | ☐ | ☐ | | | | | |

## PART C — AI VENDOR / LLM DUE-DILIGENCE QUESTIONNAIRE
*Send to any AI vendor before approving for sensitive data.*

**Vendor:** ______  **Tool:** ______  **Data it will touch:** ______

| # | Question | Response |
|---|---|---|
| 1 | Do you hold SOC 2 Type II / ISO 27001? (attach) | |
| 2 | Is our data used to train your or third-party models? Can we opt out? | |
| 3 | What is your data **retention** period? Can we set zero-retention? | |
| 4 | Is data encrypted in transit and at rest? | |
| 5 | Where is data processed/stored (region)? | |
| 6 | List sub-processors / underlying model providers (e.g., OpenAI, Anthropic). | |
| 7 | Will you sign a DPA? A BAA (if PHI)? | |
| 8 | How do you mitigate prompt injection &amp; insecure output (OWASP LLM01/LLM05)? | |
| 9 | What admin controls (SSO, MFA, role-based access, audit logs) do you provide? | |
| 10 | How is data returned/destroyed at contract end? | |

**Reviewer:** ______  **Decision:** ☐ Approve ☐ Approve w/ conditions ☐ Reject  **Date:** ______

| Version | Date | Author | Change |
|---|---|---|---|
| 1.0 | [DATE] | [NAME] | Initial issue |
